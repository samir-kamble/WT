alert('write functions after section just loaded');



      