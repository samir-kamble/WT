function generateGraph(json_name) {
    var json_name;
    //========Get data from JSON===============//
    $.getJSON("json/"+json_name, function(json){
        var class_data;
        class_data = json;
        var page_data = class_data;
        
    //=====Pushing values on the page=====//
        $("#tot_gain").html(page_data.total_gain[0].value);
        $("#xirr").html(page_data.xirr[0].value);

        var temp_cats, temp_data;

    //-----------Getting colors from JSON------------//
        var palette = g_data.colors[0].palette;
        var temp_colors = new Array();
        temp_colors = palette.split(",");

        //-----------Getting drill data from JSON for top 10 clients------------//
        var chartSeriesData = [];
        var chartDrilldownData = [];
        var chartdata = g_data.top_10_clients;
        //console.log(chartdata);

        for (var i = 0;i <chartdata.length; i++)
        {
            var series_name = chartdata[i].name;
            var drill_id = chartdata[i].drilldown;
            var series_data = chartdata[i].y;
            var drill_data = chartdata[i].data;
            //alert(drill_data);

            chartSeriesData.push({
                name: series_name,
                y: parseFloat(series_data),
                drilldown : drill_id                                     
            }); 

            chartDrilldownData.push({
                 data : drill_data,
                 id: drill_id,
                 name: series_name,
            });
        }
        //console.log(chartSeriesData);
        //console.log(chartDrilldownData);

        // set the theme
        Highcharts.setOptions({
           colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB'],
            chart: {
              backgroundColor:'rgba(255, 255, 255, 0)'
            },
            title: {
              style: {
                color: '#000',
                font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            subtitle: {
              style: {
                color: '#666666',
                font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                tickColor: '#000',
                labels: {
                style: {
                  color: '#000',
                  font: '11px Trebuchet MS, Verdana, sans-serif'
                }
              },
              title: {
                style: {
                  color: '#333',
                  fontWeight: 'bold',
                  fontSize: '12px',
                  fontFamily: 'Trebuchet MS, Verdana, sans-serif'

                }
              }
            },
            yAxis: {
              alternateGridColor: null,
              minorTickInterval: 'auto',
              lineColor: '#000',
              lineWidth: 1,
              tickWidth: 1,
              tickColor: '#000',
              labels: {
                style: {
                  color: '#000',
                  font: '11px Trebuchet MS, Verdana, sans-serif'
                }
              },
              title: {
                style: {
                  color: '#333',
                  fontWeight: 'bold',
                  fontSize: '12px',
                  fontFamily: 'Trebuchet MS, Verdana, sans-serif'
                }
              }
            },
            legend: {
              itemStyle: {
                font: '9pt Trebuchet MS, Verdana, sans-serif',
                color: 'black'

              },
              itemHoverStyle: {
                color: '#039'
              },
              itemHiddenStyle: {
                color: 'gray'
              }
            },
            credits: {
               enabled: false
            },
            labels: {
              style: {
                color: '#99b'
              }
            }
        });

        // default options
            var options = {
            chart: {
              zoomType: 'xy'
            }
        };

    //========================[Pie chart with drill down] Chart 4 Configuration================//
      var chart4Options = {
            chart: {
            renderTo: 'container-pie1',
            type: 'pie',
            events: {
                    drilldown: function (e) {
                        /*$.blockUI({ message: '<h5><img src="dist/img/busy.gif" /> Work in progress...</h5>' });
                        setTimeout(function () {
                            updateGraphs();
                            $.unblockUI();
                        }, 1000);*/
                    },
                    drillup: function (e) {  
                       /* $.blockUI({ message: '<h5><img src="dist/img/busy.gif" /> Work in progress...</h5>' });
                        setTimeout(function () {
                            resetGraphs();
                            $.unblockUI();
                        }, 1000);*/
                    }
                }
            },
            title: {
                text: ''
            },
            xAxis: {
                type: 'category'
            },
            subtitle: {
                //text: 'Click the slices to see details.'
            },
            legend: {
                align: 'left',
                layout: 'vertical',
                verticalAlign: 'top',
                x: 0,
                y: 40,
                itemMarginTop: 5,
                itemMarginBottom: 5
            },
            plotOptions: {
                pie: {
                        allowPointSelect: true,
                        innerSize: 0,
                        cursor: 'pointer',
                        showInLegend: true,
                        slicedOffset: 30,
                        dataLabels: {
                            enabled: true,
                            format: '{point.y} %',
                            style: {
                               color: 'black',
                               textOutline: '0px 0px contrast'
                            }
                        },

                        showInLegend: true,
                    point: {
                        events: {
                            legendItemClick: function (e) {
                                this.slice();
                                console.log(this.sliced , this.name, json_name);

                                if(this.sliced === true){
                                    //alert('true');
                                    var chart = $('#container-pie1').highcharts();
                                    var legend = chart.legend;

                                    for (var i in legend.allItems) {
                                        var item = legend.allItems[i];
                                        if(item !=this)
                                            item.slice(false);                     
                                    }

                            //===Updating graph on selection of legend only when slice-out not slice-in===//
                            if(this.name ==="Mutual Funds"){
                                json_name = "mf_data.json";
                                $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Equity"){
                                //alert("equity");
                                json_name = "eq_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Debt"){
                                //alert("equity");
                                json_name = "deb_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Dynamic Debt"){
                                //alert("here");
                                json_name = "dyn_deb_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Debt Short Term"){
                                //alert("here");
                                json_name = "deb_short_term_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Debt Long Term"){
                                //alert("here");
                                json_name = "deb_long_term_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Diversified Equity"){
                                //alert("here");
                                json_name = "diversified_equity_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Large Cap Equity"){
                                //alert("here");
                                json_name = "large_cap_equity_data.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="Small & Mid Cap Equity"){
                                //alert("here");
                                json_name = "small_mid_cap_equity.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }else if(this.name ==="ELSS"){
                                //alert("here");
                                json_name = "elss_equity.json";
                                 $.blockUI({ message: "<h5><img src='dist/img/busy.gif' /> Loading "+this.name+" data...</h5>" });
                                setTimeout(function () {
                                    genrateonselectGraph(json_name);
                                    $.unblockUI();
                                }, 1000);
                            }
                                    
                                     
                                }
                                return false;
                            }
                        }
                    }
                    }
            },
            tooltip: {
                headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
            },
            series: [{
                states: {
                    select: {
                        color: '#666'
                    }
                },
                name: 'Portfolio Summary',
                /*point: {
                    events: {
                        click: function () {
                            console.log('Category: ' + this.category + ', value: ' + this.y);
                        }
                    }
                },*/
                
                colorByPoint: true,
                data: [{
                    name: 'Mutual Funds',
                    y: 28.31,
                    drilldown: 'Mutual Funds'
                }, {
                    name: 'Direct Equities',
                    y: 67.99,
                    drilldown: null
                }, {
                    name: 'Fixed Deposits',
                    y: 1.33,
                    drilldown: null
                }, {
                    name: 'Insurance',
                    y: 0.21,
                    drilldown: null
                }, {
                    name: 'NPS',
                    y: 0.82,
                    drilldown: null
                }, {
                    name: 'Bonds',
                    y: 0.2,
                    drilldown: null
                }]
            }],
            drilldown: {
                drillUpButton: {
                    relativeTo: 'spacingBox',
                    position: {
                        y: 0,
                        x: "-100%"
                    }
                },
                series: [{
                    id: 'Mutual Funds',
                    name: 'Mutual Funds',
                    data: [{
                        name: 'Equity',
                        y: 50.90,
                        drilldown: 'Equity'
                    },{
                        name: 'Debt',
                        y: 49.10,
                        drilldown: 'Debt'
                    }]
                }, {
                    id: 'Equity',
                    data: [
                        ['ELSS', 21.84],
                        ['Small & Mid Cap Equity', 32.03],
                        ['Large Cap Equity', 19.81],
                        ['Diversified Equity', 29.99]
                    ]
                },{
                    id: 'Debt',
                    data: [
                        ['Dynamic Debt', 23.15],
                        ['Debt Short Term', 35.37],
                        ['Debt Long Term', 41.48]
                    ]
                }]
            }
      };
      chart4Options = jQuery.extend(true, {}, options, chart4Options);
      var chart4 = new Highcharts.Chart(chart4Options);

    //========================[Top 5 performers] Chart 1 Configuration================//
      
      //=====Parsing Top5 data from JSON=====//
        top_data = page_data.top5_perf[1];
        
        //Forming categories array from string in JSON
        temp_cats = page_data.top5_perf[0].categories;
        var top5_cats= new Array();
        top5_cats = temp_cats.split(","); 
        
        chart1Options = {
            chart: {
                renderTo: 'container-bar1',
                type: 'column'
                },
            title: {
                text: ''
                },
            xAxis: {
                categories: top5_cats,
                title: {
                    text: 'Scheme name'
                }
            },
            yAxis: {
                title: {
                    text: 'Annualized Return (%)'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'%</b>';
                }
            },
            series: [top_data]
      };
      chart1Options = jQuery.extend(true, {}, options, chart1Options);
    //var chart1 = new Highcharts.Chart(chart1Options);

    //========================[Bottom 5 performers] Chart 2 Configuration================//
        
        //=====Parsing Bottom5 data from JSON=====//
        bottom_data = page_data.bottom5_perf[1];
        
        //Forming categories array from string in JSON
        temp_cats = page_data.bottom5_perf[0].categories;
        var bottom5_cats= new Array();
        bottom5_cats = temp_cats.split(",");

      var chart2Options = {
            chart: {
                renderTo: 'container-bar2',
                type: 'column'
                },
            title: {
                text: ''
                },
            xAxis: {
                categories: bottom5_cats,
                title: {
                    text: 'Scheme name'
                }
            },
            yAxis: {
                title: {
                    text: 'Annualized Return (%)'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'</b>';
                }
            },
            series: [bottom_data]
      };
      chart2Options = jQuery.extend(true, {}, options, chart2Options);
    // var chart1 = new Highcharts.Chart(chart1Options);

    //========================[Capital Gains bar chart] Chart 3 Configuration================//
       
       //=====Parsing Capital Gains data from JSON=====//
        cap_gain_data = page_data.cap_gain[1].series;
        
        //Forming categories array from string in JSON
        temp_cats = page_data.cap_gain[0].categories;
        var cap_gain_cats= new Array();
        cap_gain_cats = temp_cats.split(",");

      var chart3Options = {
            chart: {
                renderTo: 'container-bar3',
                type: 'column'
                },
            title: {
                text: 'Capital Gains'
                },
            xAxis: {
                categories: cap_gain_cats
                },
            yAxis: {
                title: {
                    text: 'In Rupees'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: 0,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'</b>';
                }
            },
             plotOptions: {
                series: {
                    stacking: 'normal'
                }
            },
            series: cap_gain_data
      };
      chart3Options = jQuery.extend(true, {}, options, chart3Options);
      var chart3 = new Highcharts.Chart(chart3Options);

    //========================[Point to Point returns Bar chart] Chart 5 Configuration================//
        
        //=====Parsing Point to Point data from JSON=====//
        ptop_data = page_data.point_to_point[1].series;

        //Forming categories array from string in JSON
        temp_cats = page_data.point_to_point[0].categories;
        var ptop_cats= new Array();
        ptop_cats = temp_cats.split(",");
        
        var chart5Options = {
            //colors: temp_colors,
            chart: {
                renderTo: 'top10-container',
                type: 'column'
                },
             title: {
                text: 'Point to Point returns'
            },
            subtitle: {
                text: ''
             },
            credits: {
                enabled: false
                },
            xAxis: {
                categories: ptop_cats,
                title: {
                    text: 'Period'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Returns (%)'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: false,
                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                    }
                }
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'</b>';
                }
            },
            series: ptop_data
      };
      chart5Options = jQuery.extend(true, {}, options, chart5Options);
      var chart5 = new Highcharts.Chart(chart5Options);

    //=======Owl Carousel for Performance Schemes========//
        var eq_car = $('#eq_car'); 
        eq_car.owlCarousel({
            items:1,
            smartSpeed:1000,
            autoplay:false,
            loop:false,
            autoplayTimeout:4000,
            autoplayHoverPause:true,
            nav:true,
            dots:false,
            navText:["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
            onInitialized: initeqchart
        });

        function initeqchart(event) {
          var chart1 = new Highcharts.Chart(chart1Options);
          var chart2 = new Highcharts.Chart(chart2Options);
        }

        $( "#eq_car" ).hover(function() {
              eq_car.trigger('stop.owl.autoplay');
            }, function() {
              eq_car.trigger('play.owl.autoplay');
            }
        );

    //=============Onchange of orientation Reinit Carousel===========//
        window.addEventListener('orientationchange', function() {
            $('#eq_car').owlCarousel('destroy');
            $('#eq_car').owlCarousel({
                items:1,
                smartSpeed:1000,
                 autoplay:false,
                //loop:true,
                autoplayTimeout:4000,
                //autoplayHoverPause:true,
                 nav:true,
                dots:false,
                navText:["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
                onInitialized: initeqchart
            });
            function initeqchart(event) {
              var chart1 = new Highcharts.Chart(chart1Options);
              var chart2 = new Highcharts.Chart(chart2Options);
            }
        });

    });
};

function genrateonselectGraph(json_name) {
    $.getJSON("json/"+json_name, function(json){
        console.log(json_name);
        var class_data;
        class_data = json;
        var page_data = class_data;
        
    //=====Pushing values on the page=====//
        $("#tot_gain").html(page_data.total_gain[0].value);
        $("#xirr").html(page_data.xirr[0].value);

        var temp_cats, temp_data;

    //-----------Getting colors from JSON------------//
        var palette = g_data.colors[0].palette;
        var temp_colors = new Array();
        temp_colors = palette.split(",");

        //-----------Getting drill data from JSON for top 10 clients------------//
        var chartSeriesData = [];
        var chartDrilldownData = [];
        var chartdata = g_data.top_10_clients;
        //console.log(chartdata);

        for (var i = 0;i <chartdata.length; i++)
        {
            var series_name = chartdata[i].name;
            var drill_id = chartdata[i].drilldown;
            var series_data = chartdata[i].y;
            var drill_data = chartdata[i].data;
            //alert(drill_data);

            chartSeriesData.push({
                name: series_name,
                y: parseFloat(series_data),
                drilldown : drill_id                                     
            }); 

            chartDrilldownData.push({
                 data : drill_data,
                 id: drill_id,
                 name: series_name,
            });
        }
        //console.log(chartSeriesData);
        //console.log(chartDrilldownData);

        // set the theme
        Highcharts.setOptions({
           colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB'],
            chart: {
              backgroundColor:'rgba(255, 255, 255, 0)'
            },
            title: {
              style: {
                color: '#000',
                font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            subtitle: {
              style: {
                color: '#666666',
                font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            xAxis: {
                gridLineWidth: 1,
                lineColor: '#000',
                tickColor: '#000',
                labels: {
                style: {
                  color: '#000',
                  font: '11px Trebuchet MS, Verdana, sans-serif'
                }
              },
              title: {
                style: {
                  color: '#333',
                  fontWeight: 'bold',
                  fontSize: '12px',
                  fontFamily: 'Trebuchet MS, Verdana, sans-serif'

                }
              }
            },
            yAxis: {
              alternateGridColor: null,
              minorTickInterval: 'auto',
              lineColor: '#000',
              lineWidth: 1,
              tickWidth: 1,
              tickColor: '#000',
              labels: {
                style: {
                  color: '#000',
                  font: '11px Trebuchet MS, Verdana, sans-serif'
                }
              },
              title: {
                style: {
                  color: '#333',
                  fontWeight: 'bold',
                  fontSize: '12px',
                  fontFamily: 'Trebuchet MS, Verdana, sans-serif'
                }
              }
            },
            legend: {
              itemStyle: {
                font: '9pt Trebuchet MS, Verdana, sans-serif',
                color: 'black'

              },
              itemHoverStyle: {
                color: '#039'
              },
              itemHiddenStyle: {
                color: 'gray'
              }
            },
            credits: {
               enabled: false
            },
            labels: {
              style: {
                color: '#99b'
              }
            }
        });

        // default options
            var options = {
            chart: {
              zoomType: 'xy'
            }
        };

    //========================[Top 5 performers] Chart 1 Configuration================//
      
      //=====Parsing Top5 data from JSON=====//
        top_data = page_data.top5_perf[1];
        
        //Forming categories array from string in JSON
        temp_cats = page_data.top5_perf[0].categories;
        var top5_cats= new Array();
        top5_cats = temp_cats.split(","); 
        
        chart1Options = {
            chart: {
                renderTo: 'container-bar1',
                type: 'column'
                },
            title: {
                text: ''
                },
            xAxis: {
                categories: top5_cats,
                title: {
                    text: 'Scheme name'
                }
            },
            yAxis: {
                title: {
                    text: 'Annualized Return (%)'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'%</b>';
                }
            },
            series: [top_data]
      };
      chart1Options = jQuery.extend(true, {}, options, chart1Options);
    //var chart1 = new Highcharts.Chart(chart1Options);

    //========================[Bottom 5 performers] Chart 2 Configuration================//
        
        //=====Parsing Bottom5 data from JSON=====//
        bottom_data = page_data.bottom5_perf[1];
        
        //Forming categories array from string in JSON
        temp_cats = page_data.bottom5_perf[0].categories;
        var bottom5_cats= new Array();
        bottom5_cats = temp_cats.split(",");

      var chart2Options = {
            chart: {
                renderTo: 'container-bar2',
                type: 'column'
                },
            title: {
                text: ''
                },
            xAxis: {
                categories: bottom5_cats,
                title: {
                    text: 'Scheme name'
                }
            },
            yAxis: {
                title: {
                    text: 'Annualized Return (%)'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'</b>';
                }
            },
            series: [bottom_data]
      };
      chart2Options = jQuery.extend(true, {}, options, chart2Options);
    // var chart1 = new Highcharts.Chart(chart1Options);

    //========================[Capital Gains bar chart] Chart 3 Configuration================//
       
       //=====Parsing Capital Gains data from JSON=====//
        cap_gain_data = page_data.cap_gain[1].series;
        
        //Forming categories array from string in JSON
        temp_cats = page_data.cap_gain[0].categories;
        var cap_gain_cats= new Array();
        cap_gain_cats = temp_cats.split(",");

      var chart3Options = {
            chart: {
                renderTo: 'container-bar3',
                type: 'column'
                },
            title: {
                text: 'Capital Gains'
                },
            xAxis: {
                categories: cap_gain_cats
                },
            yAxis: {
                title: {
                    text: 'In Rupees'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: 0,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'</b>';
                }
            },
             plotOptions: {
                series: {
                    stacking: 'normal'
                }
            },
            series: cap_gain_data
      };
      chart3Options = jQuery.extend(true, {}, options, chart3Options);
      var chart3 = new Highcharts.Chart(chart3Options);

    //========================[Point to Point returns Bar chart] Chart 5 Configuration================//
        
        //=====Parsing Point to Point data from JSON=====//
        ptop_data = page_data.point_to_point[1].series;

        //Forming categories array from string in JSON
        temp_cats = page_data.point_to_point[0].categories;
        var ptop_cats= new Array();
        ptop_cats = temp_cats.split(",");
        
        var chart5Options = {
            //colors: temp_colors,
            chart: {
                renderTo: 'top10-container',
                type: 'column'
                },
             title: {
                text: 'Point to Point returns'
            },
            subtitle: {
                text: ''
             },
            credits: {
                enabled: false
                },
            xAxis: {
                categories: ptop_cats,
                title: {
                    text: 'Period'
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Returns (%)'
                },
                stackLabels: {
                    enabled: false,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },
            legend: {
                enabled: false,
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: false,
                        color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                    }
                }
            },
            tooltip: {
                formatter: function () {
                return this.x + '<br/>' + '<b>' + this.series.name + ': ' + this.y +'</b>';
                }
            },
            series: ptop_data
      };
      chart5Options = jQuery.extend(true, {}, options, chart5Options);
      var chart5 = new Highcharts.Chart(chart5Options);

    //=======Owl Carousel for Performance Schemes========//
       
        var eq_car = $('#eq_car'); 
        eq_car.owlCarousel('destroy');
        eq_car.owlCarousel({
            items:1,
            smartSpeed:1000,
             autoplay:false,
            loop:false,
            autoplayTimeout:4000,
            autoplayHoverPause:true,
            nav:true,
            dots:false,
            navText:["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
            onInitialized: initeqchart
        });

        function initeqchart(event) {
          var chart1 = new Highcharts.Chart(chart1Options);
          var chart2 = new Highcharts.Chart(chart2Options);
        }

        $( "#eq_car" ).hover(function() {
              eq_car.trigger('stop.owl.autoplay');
            }, function() {
              eq_car.trigger('play.owl.autoplay');
            }
        );

    //=============Onchange of orientation Reinit Carousel===========//
        window.addEventListener('orientationchange', function() {
            $('#eq_car').owlCarousel('destroy');
            $('#eq_car').owlCarousel({
                items:1,
                smartSpeed:1000,
                 autoplay:false,
                //loop:true,
                autoplayTimeout:4000,
                autoplayHoverPause:true,
                 nav:true,
                dots:false,
                navText:["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
                onInitialized: initeqchart
            });
            function initeqchart(event) {
              var chart1 = new Highcharts.Chart(chart1Options);
              var chart2 = new Highcharts.Chart(chart2Options);
            }
        });

    });
};

