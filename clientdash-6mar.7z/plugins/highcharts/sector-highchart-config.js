function generateGraph() {
  // set the theme
  Highcharts.setOptions({
    colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
    chart: {
    },
    title: {
      style: {
        color: '#000',
        font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
      }
    },
     
    subtitle: {
      style: {
        color: '#666666',
        font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
      }
    },
    xAxis: {
      gridLineWidth: 1,
      lineColor: '#000',
      tickColor: '#000',
      labels: {
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'

        }
      }
    },
    yAxis: {
      alternateGridColor: null,
      minorTickInterval: 'auto',
      lineColor: '#000',
      lineWidth: 1,
      tickWidth: 1,
      tickColor: '#000',
      labels: {
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'
        }
      }
    },
    legend: {
      itemStyle: {
        font: '9pt Trebuchet MS, Verdana, sans-serif',
        color: 'black'

      },
      itemHoverStyle: {
        color: '#039'
      },
      itemHiddenStyle: {
        color: 'gray'
      }
    },
    credits: {
       enabled: false
    },
    labels: {
      style: {
        color: '#99b'
      }
    }
  });

  // default options
  var options = {
    chart: {
      zoomType: 'xy'
    }
  };

//========================Chart 1 Configuration================//
  var chart1Options = {
    chart: {
      renderTo: 'container-sectors-bar',
      type: 'column'
    },
    title: {
            text: ''
    },
    xAxis: {
        categories: ['Copper & Copper products',
            'Ship Building',
            'Steel',
            'Logistics Solution Provider',
            'Paper & Paper products',
            'Sugar',
            'Pig Iron']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Total (Rs.Cr.)'
        },
        stackLabels: {
            enabled: false,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    legend: {
        enabled: false,
        align: 'right',
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        borderColor: '#CCC',
        borderWidth: 1,
        shadow: false
    },
    tooltip: {
        //headerFormat: '<b>{point.x}</b><br/>',
       pointFormat: '<b>{point.y}</b>'
    },
    plotOptions: {
        column: {
            stacking: 'normal',
            dataLabels: {
                enabled: false,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }
        }
    },
    series: [{
        data: [32.36, 0, 0, 0, 0, 0, 0]
        }, {
            data: [0, 21.11, 0, 0, 0, 0, 0]
        }, {
            data: [0, 0, 9.97, 0, 0, 0, 0]
        }, {
            data: [0, 0, 0, 4.6, 0, 0, 0]
        }, {
            data: [0, 0, 0, 0, 2.98, 0, 0]
        }, {
            data: [0, 0, 0, 0, 0, 1.13, 0]
        }, {
            data: [0, 0, 0, 0, 0, 0, 0.23]
        }]
  };
  chart1Options = jQuery.extend(true, {}, options, chart1Options);
  var chart1 = new Highcharts.Chart(chart1Options);

//========================Chart 2 Configuration================//
  var chart2Options = {
    chart: {
      renderTo: 'container-sectors-bubble',
       type: 'bubble',
        plotBorderWidth: 1
    },
    legend: {
            enabled: false
    },

    title: {
        text: ''
    },

    subtitle: {
        text: ''
    },

    xAxis: {
        gridLineWidth: 1,
        title: {
            text: '% to Scheme NAV'
        },
        labels: {
            format: '{value}'
        }
    },
    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Investment Allocation (Rs.Cr.)'
        },
        labels: {
            format: '{value}'
        },
        maxPadding: 0.2
    },
    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2">{point.name}</th></tr>' +
            '<tr><th>Total:</th><td>{point.x}Rs. Cr</td></tr>' +
            '<tr><th>Inv Allocation:</th><td>{point.y}Rs. Cr</td></tr>' +
            '<tr><th>% Scheme to NAV:</th><td>{point.z}%</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },
    plotOptions: {
        series: {
            dataLabels: {
                enabled: false,
                format: '{point.name}'
            }
        }
    },

    series: [{
        data: [
            { x: 3.63, y: 217.2, z: 1.67, name: 'Birla Sun Life Savings Fund'},
            { x: 18.49, y: 525.02, z: 3.52, name: 'ICICI Prudential Flexible Income Plan'},
            { x: 3.33, y: 131.9, z: 2.53, name: 'IFCI Tax Saving Bond'},
            { x: 9.37, y: 525.02, z: 1.78, name: 'ICICI Prudential Flexible Income Plan'},
            { x: 0.6, y: 32, z: 1.87, name: 'Tata Floater Fund'},
            { x: 0.38, y: 2.37, z: 1.88, name: 'DWS Arbitrage Fund'},
            { x: 0.75, y: 101.49, z: 0.74, name: 'DWS Ultra Short Term Fund'},
            { x: 0.17, y: 30.28, z: 0.56, name: 'IDFC Bond'},
            { x: 10.92, y: 217.2, z: 5.03, name: 'Birla Sun Life Savings Fund'},
            { x: 3.56, y: 101.49, z: 3.51, name: 'DWS Ultra Short Term Fund'},
            { x: 3.08, y: 525.02, z: 0.59, name: 'ICICI Prudential Flexible Income Plan'},
            { x: 14.81, y: 301.54, z: 4.91, name: 'Reliance Medium Term Fund'},
            { x: 0.23, y: 40, z: 0.57, name: 'HDFC Floating Rate Income Fund - Short Term Plan'},
            { x: 4.6, y: 525.02, z: 0.88 , name: 'ICICI Prudential Flexible Income Plan'},
            { x: 2.98, y: 101.49, z: 2.94 , name: 'DWS Ultra Short Term Fund'}
        ]
    }]
  };
  chart2Options = jQuery.extend(true, {}, options, chart2Options);
  var chart2 = new Highcharts.Chart(chart2Options);
};