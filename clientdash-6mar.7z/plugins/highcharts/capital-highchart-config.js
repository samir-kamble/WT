function generateGraph() {
    // Create the chart
    Highcharts.chart('container-capital-bar', {
        colors: ['#1E6166','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
        chart: {
             type: 'column'
        },
         title: {
            text: 'Gains/Losses'
        },
        credits: {
                enabled: false
        },
        xAxis: {
            categories: ['Equity', 'Debt', 'Gold', 'Liquid']
        },

        yAxis: {
            
            title: {
                text: 'in Rs.'
            }
        },

        tooltip: {
            formatter: function () {
                return '<b>' + this.x + '</b><br/>' +
                    this.series.name + ': ' + this.y;
            }
        },

        plotOptions: {
            series: {
                stacking: 'normal'
            }
        },

        series: [{
            name: 'Long term gains(Realized)',
            data: [-200, -50, 1000, 500],
            stack: 'Realized'
        }, {
            name: 'Short term gains(Realized)',
            data: [300, 200, 1000, 300],
            stack: 'Realized'
        },
        {
            name: 'Long term gains(Unrealized)',
            data: [500, 200, 500, 400],
            stack: 'Unrealized'
        }, {
            name: 'Short term gains(Unrealized)',
            data: [500, -200, 300, 1000],
            stack: 'Unrealized'
        }]
    });
};