function generateGraph() {

    var categories = ['ABC Gold Exchange Traded Fund', 'ABC Liquid Fund', 'ABC Corporate Bond Fund', 'ABC Midcap', 'ABC Top 100'];
    
  // set the theme
  Highcharts.setOptions({
    colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
    chart: {
      
    },
    title: {
      style: {
        color: '#000',
        font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
      }
    },
     
    subtitle: {
      style: {
        color: '#666666',
        font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
      }
    },
    xAxis: {
      gridLineWidth: 1,
      lineColor: '#000',
      tickColor: '#000',
      labels: {
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'

        }
      }
    },
    yAxis: {
      alternateGridColor: null,
      minorTickInterval: 'auto',
      lineColor: '#000',
      lineWidth: 1,
      tickWidth: 1,
      tickColor: '#000',
      labels: {
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'
        }
      }
    },
    legend: {
      itemStyle: {
        font: '9pt Trebuchet MS, Verdana, sans-serif',
        color: 'black'

      },
      itemHoverStyle: {
        color: '#039'
      },
      itemHiddenStyle: {
        color: 'gray'
      }
    },
    credits: {
       enabled: false
    },
    labels: {
      style: {
        color: '#99b'
      }
    }
  });

  // default options
  var options = {
    chart: {
      zoomType: 'xy'
    },

    xAxis: {
      type: 'datetime'
    }
  };

//========================Chart 1 Configuration================//
  var chart1Options = {
    chart: {
      renderTo: 'container-performance-bar',
      type: 'bar'
    },
    title: {
                text: 'Performance'
            },
            subtitle: {
                text: ''
            }, 
            legend: {
              enabled: false
            },
            credits: {
                enabled: false
            },
            xAxis: [{
                categories: categories,
                reversed: false,
                labels: {
                    step: 1
                }
            }],
            yAxis: {
                title: {
                    text: 'Annualised Return (%)'
                },
                labels: {
                    formatter: function () {
                        return Math.abs(this.value) + '%';
                    }
                }
            },
            plotOptions: {
                series: {
                    stacking: 'normal'
                }
            },
            series: [{
                name: 'Annualised Return (%)',
                data: [2.20, 7.97, 7.30, -10.20, -7.90]
            }]
  };
  chart1Options = jQuery.extend(true, {}, options, chart1Options);
  var chart1 = new Highcharts.Chart(chart1Options);

//========================Chart 2 Configuration================//
  var chart2Options = {
    chart: {
      renderTo: 'container-performance-pie',
      type: 'pie'
    },
    title: {
            text: 'Exposure'
        },
        subtitle: {
            text: ''
        },
        plotOptions: {
            pie: {
                innerSize: 100,
                depth: 45,
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: [{
            name: 'Total',
            data: [
                ['Equity', 60],
                ['Debt', 25],
                ['Gold', 10],
                ['Liquid', 5]
            ]
        }]
  };
  chart2Options = jQuery.extend(true, {}, options, chart2Options);
  var chart2 = new Highcharts.Chart(chart2Options);

//========================Chart 1 Configuration================//
  var chart3Options = {
    chart: {
      renderTo: 'container-performance-tran-bar',
      type: 'bar'
    },
    title: {
               text: 'Performance'
            },
            subtitle: {
                text: ''
            }, 
            legend: {
              enabled: false
            },
            credits: {
                enabled: false
            },
            xAxis: [{
                categories: categories,
                reversed: false,
                labels: {
                    step: 1
                }
            }],
            yAxis: {
                title: {
                    text: 'Annualised Return (%)'
                },
                labels: {
                    formatter: function () {
                        return Math.abs(this.value) + '%';
                    }
                }
            },
            plotOptions: {
                series: {
                    stacking: 'normal'
                }
            },
            series: [{
                name: 'Annualised Return (%)',
                data: [2.20, 7.97, 7.30, -10.20, -7.90]
            }]
  };
  chart3Options = jQuery.extend(true, {}, options, chart3Options);
  var chart3 = new Highcharts.Chart(chart3Options);

//========================Chart 4 Configuration================//
  var chart4Options = {
    chart: {
      renderTo: 'container-performance-tran-pie',
      type: 'pie'
    },
    title: {
            text: 'Exposure'
        },
        subtitle: {
            text: ''
        },
        plotOptions: {
            pie: {
                innerSize: 100,
                depth: 45,
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: [{
            name: 'Total',
            data: [
                ['Equity', 60],
                ['Debt', 25],
                ['Gold', 10],
                ['Liquid', 5]
            ]
        }]
  };
  chart4Options = jQuery.extend(true, {}, options, chart4Options);
  var chart4 = new Highcharts.Chart(chart4Options);


};