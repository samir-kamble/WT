function generateGraph() {
    
 // Age categories
    var categories = ['ABC Top 100','ABC Midcap','ABC Corporate Bond Fund','ABC Gold Exchange Traded Fund','ABC Liquid Fund'];

    // Create the chart
   Highcharts.chart('container-contri-bar', {
    colors: ['#1E6166','#4F9BA0'],
            chart: {
                type: 'bar'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: [{
                categories: categories,
                reversed: false,
                labels: {
                    step: 1
                }
            }],
            yAxis: {
                title: {
                    text: null
                }
            },

            plotOptions: {
                bar:{
                    dataLabels: {
                        enabled: true
                    }
                }
            },

          

            series: [{
                name: 'Scheme XIRR (%)',
                data: [28.98 , 23.06 , 11.11 , -0.94 , 8.43]
            }, {
                name: 'Index XIRR (%)',
                data: [15.93 , 17.17 , 11.86 , -0.96 , 8.37]
            }]
        });
};