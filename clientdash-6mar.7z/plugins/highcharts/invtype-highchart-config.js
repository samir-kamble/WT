function generateGraph() {
  // set the theme
  Highcharts.setOptions({
    colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
    chart: {
      
    },
    title: {
      style: {
        color: '#000',
        font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
      }
    },
     
    subtitle: {
      style: {
        color: '#666666',
        font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
      }
    },
    xAxis: {
      gridLineWidth: 1,
      lineColor: '#000',
      tickColor: '#000',
      labels: {
        rotation: -20,
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'

        }
      }
    },
    yAxis: {
      alternateGridColor: null,
      minorTickInterval: 'auto',
      lineColor: '#000',
      lineWidth: 1,
      tickWidth: 1,
      tickColor: '#000',
      labels: {
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'
        }
      }
    },
    legend: {
      itemStyle: {
        font: '9pt Trebuchet MS, Verdana, sans-serif',
        color: 'black'

      },
      itemHoverStyle: {
        color: '#039'
      },
      itemHiddenStyle: {
        color: 'gray'
      }
    },
    credits: {
       enabled: false
    },
    labels: {
      style: {
        color: '#99b'
      }
    }
  });

  // default options
  var options = {
    chart: {
      zoomType: 'xy'
    },

    xAxis: {
      type: 'datetime'
    }
  };

//========================Chart 1 Configuration================//
  var chart1Options = {
        chart: {
            type: 'pie',
            renderTo: 'container-effront-pie1'
        },
        title: {
            text: 'Investment Type'
        },
        subtitle: {
            text: ''
        },
         credits: {
                enabled: false
            },
        plotOptions: {
            pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '{point.y} %'
                    },
                    showInLegend: true
                }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
        },
        series: [{
            name: 'Investment Type',
            colorByPoint: true,
            data: [{
                name: 'Debt',
                y: 51.5
            }, {
                name: 'Equity',
                y: 30.05
            }, {
                name: 'Liquid ',
                y: 10.79
            }, {
                name: 'Hybrid',
                y: 5.37
            }, {
                name: 'Commodity',
                y: 2.20
            }, {
                name: 'International',
                y: 0.08
            }]
        }]
  };
  chart1Options = jQuery.extend(true, {}, options, chart1Options);
  var chart1 = new Highcharts.Chart(chart1Options);


};