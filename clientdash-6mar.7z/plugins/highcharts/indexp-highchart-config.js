function generateGraph() {
  // set the theme
  Highcharts.setOptions({
    colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
    chart: {
      
    },
    title: {
      style: {
        color: '#000',
        font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
      }
    },
     
    subtitle: {
      style: {
        color: '#666666',
        font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
      }
    },
    xAxis: {
      gridLineWidth: 1,
      lineColor: '#000',
      tickColor: '#000',
      labels: {
        rotation: -20,
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'

        }
      }
    },
    yAxis: {
      alternateGridColor: null,
      minorTickInterval: 'auto',
      lineColor: '#000',
      lineWidth: 1,
      tickWidth: 1,
      tickColor: '#000',
      labels: {
        style: {
          color: '#000',
          font: '11px Trebuchet MS, Verdana, sans-serif'
        }
      },
      title: {
        style: {
          color: '#333',
          fontWeight: 'bold',
          fontSize: '12px',
          fontFamily: 'Trebuchet MS, Verdana, sans-serif'
        }
      }
    },
    legend: {
      itemStyle: {
        font: '9pt Trebuchet MS, Verdana, sans-serif',
        color: 'black'

      },
      itemHoverStyle: {
        color: '#039'
      },
      itemHiddenStyle: {
        color: 'gray'
      }
    },
    credits: {
       enabled: false
    },
    labels: {
      style: {
        color: '#99b'
      }
    }
  });

  // default options
  var options = {
    chart: {
      zoomType: 'xy'
    },

    xAxis: {
      type: 'datetime'
    }
  };

//========================Chart 1 Configuration================//
  var chart1Options = {
    chart: {
      renderTo: 'container-indexp-bar',
      type: 'column'
    },
    title: {
            text: 'Industry/Company Exposure Report'
    },
    xAxis: {
      title: {
            text: 'Company name'
        },
        categories: ['Canara Bank','IDBI Bank Ltd.','Indusind Bank Ltd.','Syndicate Bank','Corporation Bank','NABRD','Allahabad Bank','UCO Bank','Andhra Bank','Oriental Bank Of Commerce','HDFC Ltd.','Axis Bank Ltd.','Export Import Bank Of India','South Indian Bank Ltd.','Punjab & Sind Bank']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Exposure (%)'
        },
        stackLabels: {
            enabled: false,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    legend: {
        enabled: false,
        align: 'right',
        x: -30,
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        borderColor: '#CCC',
        borderWidth: 1,
        shadow: false
    },
    tooltip: {
        //headerFormat: '<b>{point.x}</b><br/>',
       pointFormat: '<b>{point.y}</b>'
    },
    plotOptions: {
        column: {
            stacking: 'normal',
            dataLabels: {
                enabled: false,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }
        }
    },
    series: [{
            data: [6.97,0, 0, 0, 0, 0, 0,0,0,0,0,0,0,0,0]
        }, {
            data: [0,5.40, 0, 0, 0, 0, 0,0,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 5, 0, 0, 0, 0,0,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 4.61, 0, 0, 0,0,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 4.45, 0, 0,0,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 4.45, 0,0,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 4.02,0,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,3.45,0,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,3.43,0,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,0,3.38,0,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,0,0,3.37,0,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,0,0,0,1.98,0,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,0,0,0,0,1.80,0,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,0,0,0,0,0,1.73,0]
        }, {
            data: [0,0, 0, 0, 0, 0, 0,0,0,0,0,0,0,0,1.63]
        }]
  };
  chart1Options = jQuery.extend(true, {}, options, chart1Options);
  var chart1 = new Highcharts.Chart(chart1Options);

};