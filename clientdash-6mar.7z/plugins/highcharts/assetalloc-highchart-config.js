function generateGraph() {
    // Create the chart
    Highcharts.chart('container-assetalloc-pie', {
        colors: ['#1E6166','#226D73','#267980','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
        chart: {
            type: 'pie'
        },
        title: {
            text: 'Exposure'
        },
        subtitle: {
            text: ''
        },
         credits: {
                enabled: false
            },
        plotOptions: {
            pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '{point.y} %'
                    },
                    showInLegend: true
                }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
        },
        series: [{
            name: 'Asset allocation',
            colorByPoint: true,
            data: [{
                name: 'Equity',
                y: 52.83
            }, {
                name: 'NCD & Bonds',
                y: 22.52
            }, {
                name: 'GOI',
                y: 10.79
            }, {
                name: 'CD',
                y: 5.57
            }, {
                name: 'CBLO',
                y: 4.28
            }, {
                name: 'Net Receivables',
                y: 3.45
            }, {
                name: 'CP',
                y: 0.31
            }, {
                name: 'Warrants',
                y: 0.14
            }, {
                name: 'T-Bills',
                y: 0.09
            }]
        }]
    });
};