function generateGraph() {
    
 // Age categories
    var categories = ['Fixed income funds', 'Short term fixed income funds', 'Liquid funds', 'Short term funds', 'Equity funds'];

    // Create the chart
   Highcharts.chart('container-contri-bar', {
    colors: ['#1E6166','#3C9096','#4F9BA0','#63A6AB','#76B1B5','#8ABCC0','#9DC7CA'],
            chart: {
                type: 'bar'
            },
            title: {
                text: 'Allocation & Selection Effect'
            },
            subtitle: {
                text: ''
            },
            xAxis: [{
                categories: categories,
                reversed: false,
                labels: {
                    step: 1,
                    rotation: -40,
                    style: {
                        fontSize: '10px',
                        fontFamily: 'arial, sans-serif'
                        }
                }
            }],
            yAxis: {
                title: {
                    text: null
                }

            },

            plotOptions: {
                series: {
                    stacking: 'normal'
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + ': ' + this.point.y + '%</b><br/>' + this.point.category;
                }
            },
            series: [{
                name: 'Allocation',
                data: [0.05, 0.25, -0.10, 0.00, 0.20]
            }, {
                name: 'Selection',
                data: [0.75, -0.05, -0.10, -0.20, 0.80]
            }]
        });
};