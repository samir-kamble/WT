function generateGraph() {

    Highcharts.theme = {
    colors: ['#267980','#29858C','#3C9096','#4F9BA0','#63A6AB','#76B1B5'],
   
    title: {
        style: {
            color: '#000',
            font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
        }
    },
    subtitle: {
        style: {
            color: '#666666',
            font: 'bold 12px "Trebuchet MS", Verdana, sans-serif'
        }
    },

    legend: {
        itemStyle: {
            font: '9pt Trebuchet MS, Verdana, sans-serif',
            color: 'black'
        },
        itemHoverStyle:{
            color: 'gray'
        }   
    }
};

// Apply the theme
Highcharts.setOptions(Highcharts.theme);

    // Create the chart
    Highcharts.chart('container-summary-pie', {
        chart: {
            type: 'pie'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: 'Click the slices to see details.'
        },
         credits: {
                enabled: false
            },
        plotOptions: {
            pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '{point.y} %',
                        style: {
                           color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                        }
                    },
                    showInLegend: true
                }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
        },
        series: [{
            name: 'Portfolio Summary',
            colorByPoint: true,
            data: [{
                name: 'Mutual Funds',
                y: 28.31,
                drilldown: 'Mutual Funds'
            }, {
                name: 'Direct Equities',
                y: 67.99,
                drilldown: 'Direct Equities'
            }, {
                name: 'Fixed Deposits',
                y: 1.33,
                drilldown: 'Fixed Deposits'
            }, {
                name: 'Insurance',
                y: 0.21,
                drilldown: null
            }, {
                name: 'NPS',
                y: 0.82,
                drilldown: null
            }, {
                name: 'Bonds',
                y: 0.2,
                drilldown: 'Bonds'
            }]
        }],
        drilldown: {
            series: [{
                name: 'Mutual Funds',
                id: 'Mutual Funds',
                data: [
                    ['Equity', 50.90],
                    ['General Debt', 49.10],
                    ['Liquid', 0.00]
                ]
            }, {
                name: 'Direct Equities',
                id: 'Direct Equities',
                data: [
                    ['Large Cap', 49.20],
                    ['Mid Cap', 45.00],
                    ['Small Cap', 5.80]
                ]
            }, {
                name: 'Fixed Deposits',
                id: 'Fixed Deposits',
                data: [
                    ['ICICI 3 Year Term Deposit', 40.33],
                    ['ICICI Tax Saver FD 80C (5 year)', 59.67]
                ]
            }, {
                name: 'Bonds',
                id: 'Bonds',
                data: [
                    ['IFCI Tax Saving Infrastructure Bond', 40.33],
                    ['IDFC Infrastructure Bond', 59.67]
                ]
            }]
        }
    });
};