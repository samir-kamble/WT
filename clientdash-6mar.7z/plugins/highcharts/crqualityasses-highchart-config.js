function generateGraph() {
    // Create the chart
    Highcharts.chart('container-crquality-series', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Portfolio Credit Score'
    },
    subtitle: {
        text: ''
    },
    xAxis: {
         categories: ['Dec-13', 'Mar-14', 'Jun-14', 'Sep-14', 'Dec-14', 'Mar-15', 'Jun-15', 'Sep-15', 'Dec-15', 'Mar-16', 'Jun-16', 'Sep-16']
    },
    yAxis: {
        title: {
            text: 'Credit Score'
        }
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
    },
    plotOptions: {
        area: {
            marker: {
                enabled: false,
                symbol: 'circle',
                radius: 2,
                states: {
                    hover: {
                        enabled: false
                    }
                }
            }
        }
    },
    series: [{
        name: 'Tier1',
        enableMouseTracking: false,
        data: [10, 10,10, 10,10, 10,10, 10,10, 10,10, 10]
    }, {
        name: 'Tier2',
        enableMouseTracking: false,
        data: [17, 17,17, 17,17, 17,17, 17,17, 17,17, 17]
    },{
        name: 'Tier3',
        enableMouseTracking: false,
        data: [26, 26,26, 26,26, 26,26, 26,26, 26,26, 26]
    }, {
        name: 'Credit Score',
        fillOpacity: 0.1,
        marker: {
                enabled: true,
                symbol: 'circle',
                radius: 4
        },
        data: [ 4.05, 4.01, 4.03, 4.07, 4.20, 4.00, 4.10, 3.80, 3.85, 4.02, 4.08, 4.21]
    }]
});
};