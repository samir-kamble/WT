import { Component } from '@angular/core';
import { SortablejsOptions } from 'angular-sortablejs';

@Component({
  selector: 'app-multiple-lists',
  templateUrl: './sortable.component.html',
  styleUrls: ['./sortable.component.css']
})
export class SortableComponent {
  univState;

  // Screener example
  basic = [
    {
      "name" : 'Basic 1',
      "type" : "basic"
    },
    {
      "name" : 'Basic 2',
      "type" : "basic"
    },{
      "name" : 'Basic 3',
      "type" : "basic"
    }
  ];
  aum = [
    {
      "name" : 'AUM 1',
      "type" : "aum"
    },
    {
      "name" : 'AUM 2',
      "type" : "aum"
    },{
      "name" : 'AUM 3',
      "type" : "aum"
    }
  ];
  selected = [];
  basicOptions: SortablejsOptions = {
    handle: ".my-handle",
    ghostClass: "ghost",
    group: {
      name: 'basic',
      put: ['selected'],
    }
  };
  aumOptions: SortablejsOptions = {
    group: {
      name: 'aum',
      put: ['selected'],
    }
  };
  selectedOptions: SortablejsOptions = {
    onStart: (evt) => {
      this.univState = this.selected[evt.oldIndex].type; 
    },
    onMove: (evt)=> {
      //console.log(this.univState);
      //console.log(evt.to.id);    // target list id

      if(this.univState != evt.to.id){
        evt.preventDefault();
        console.log('Cannot drop here');
        return false;
      }

    },
    onEnd: (evt)=> {
      console.log('End Event');
    },
    group: {
      name: 'selected',
      put: ['basic', 'aum']
    }
  };

  // IPS example
  ipsMfilter = [
    {
      "name" : 'MF Filter',
      "type" : "ipsMfilter"
    }
  ];
  ipsBasic = [
    {
      "name" : 'Basic 1',
      "type" : "ipsBasic"
    },
    {
      "name" : 'Basic 2',
      "type" : "ipsBasic"
    },{
      "name" : 'Basic 3',
      "type" : "ipsBasic"
    }
  ];
  ipsAum = [
    {
      "name" : 'AUM 1',
      "type" : "ipsAum"
    },
    {
      "name" : 'AUM 2',
      "type" : "ipsAum"
    },{
      "name" : 'AUM 3',
      "type" : "ipsAum"
    }
  ];
  ipsSelected1 = [];
  ipsSelected2 = [];
  
  ipsMfilterOptions: SortablejsOptions = {
    group: {
      name: 'ipsMfilter',
      pull: 'clone',
      put: false,
    }
  };
  
  ipsBasicOptions: SortablejsOptions = {
    group: {
      name: 'ipsBasic',
      put: ['ipsSelected'],
    }
  };
  
  ipsAumOptions: SortablejsOptions = {
    group: {
      name: 'ipsAum',
      put: ['ipsSelected'],
    }
  };
  
  ipsSelectedOptions1: SortablejsOptions = {
    group: {
      name: 'ipsSelected1',
      put: ['ipsBasic', 'ipsAum', 'ipsMfilter']
    }
  };

  ipsSelectedOptions2: SortablejsOptions = {
    group: {
      name: 'ipsSelected2',
      put: ['ipsBasic', 'ipsAum', 'ipsMfilter']
    }
  };

}