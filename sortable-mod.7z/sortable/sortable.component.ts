import { Component } from '@angular/core';
import { SortablejsOptions } from 'angular-sortablejs';

@Component({
  selector: 'app-multiple-lists',
  templateUrl: './sortable.component.html',
  styleUrls: ['./sortable.component.css']
})
export class SortableComponent {
  univState;

  // super example
  basic = [
    {
      "name" : 'Basic 1',
      "type" : "basic"
    },
    {
      "name" : 'Basic 2',
      "type" : "basic"
    },{
      "name" : 'Basic 3',
      "type" : "basic"
    }
  ];

  aum = [
    {
      "name" : 'AUM 1',
      "type" : "aum"
    },
    {
      "name" : 'AUM 2',
      "type" : "aum"
    },{
      "name" : 'AUM 3',
      "type" : "aum"
    }
  ];

  selected = [];

  basicOptions: SortablejsOptions = {
    group: {
      name: 'basic',
      put: ['selected'],
    }
  };

  aumOptions: SortablejsOptions = {
    group: {
      name: 'aum',
      put: ['selected'],
    }
  };

  selectedOptions: SortablejsOptions = {
    onStart: (evt) => {
      this.univState = this.selected[evt.oldIndex].type; 
    },
    onMove: (evt)=> {
      //console.log(this.univState);
      //console.log(evt.to.id);    // target list id

      if(this.univState != evt.to.id){
        evt.preventDefault();
        console.log('Cannot drop here');
        return false;
      }

    },
    onEnd: (evt)=> {
      console.log('End Event');
    },
    group: {
      name: 'selected',
      put: ['basic', 'aum']
    }
  };

}