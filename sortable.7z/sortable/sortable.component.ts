import { Component } from '@angular/core';
import { SortablejsOptions } from 'angular-sortablejs';

@Component({
  selector: 'app-multiple-lists',
  templateUrl: './sortable.component.html',
  styleUrls: ['./sortable.component.css']
})
export class SortableComponent {

  // super example
  basic = [
    {
      "name" : 'Basic 1',
      "type" : "basic"
    },
    {
      "name" : 'Basic 2',
      "type" : "basic"
    },{
      "name" : 'Basic 3',
      "type" : "basic"
    }
  ];

  aum = [
    {
      "name" : 'AUM 1',
      "type" : "aum"
    },
    {
      "name" : 'AUM 2',
      "type" : "aum"
    },{
      "name" : 'AUM 3',
      "type" : "aum"
    }
  ];

  selected = [];

  basicOptions: SortablejsOptions = {
    onAdd: (evt) => {
      console.log(evt);
    },
    group: {
      name: 'basic',
      put: ['selected'],
    }
  };

  aumOptions: SortablejsOptions = {
    onAdd: (evt) => {
      console.log(evt);
      //console.log(JSON.stringify(this.aum));
    },
    group: {
      name: 'aum',
      put: ['selected'],
    }
  };

  selectedOptions: SortablejsOptions = {
    onAdd: (evt) => {
      //console.log(evt);
      
      //console.log('Selected filters : '+ JSON.stringify(this.selected));
    },
    onStart: (evt) => {
      //console.log(evt.oldIndex);
      //console.log('Selected item : '+ JSON.stringify(this.selected[evt.oldIndex].type));

      //console.log(JSON.stringify(this.selected[evt.oldIndex]));
      
      //console.log('Selected filters : '+ JSON.stringify(this.selected));
    },
    group: {
      name: 'selected',
      put: ['basic', 'aum']
    }
  };

}