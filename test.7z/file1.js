 var global_data,tempdata;

$( "#button" ).on( "click", function() {
	alert('click');
	var link = $.ajax({
		url: "index3.html",
		success: function(result){
	    tempdata = result;
		}
	});

	$.ajax({
		url: "http://localhost/wordpress/wp-json/wp/v2/reciepe/",
		success: function(result){
	    getData(result);
	    console.log('success');
	    $("#content").html(tempdata);
		}
	});


	function getData(data) {
	global_data = data;
	}
	console.log('from file1');
	console.log(global_data);
});


